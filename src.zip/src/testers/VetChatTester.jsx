import React, { useEffect, useMemo, useRef, useState } from "react";
import { marked } from "marked";
import DOMPurify from "dompurify";
import { API_BASE, RELAY_BASE } from "../config";

/* ───────────────────── Markdown helpers ───────────────────── */
marked.setOptions({ gfm: true, breaks: true });
const mdToHtml = (s = "") =>
  DOMPurify.sanitize(marked.parse(s), { USE_PROFILES: { html: true } });
const escapeHtml = (s = "") =>
  s.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");

/* ───────────────────── Component ───────────────────── */
export default function VetChatTester() {
  const [consultationId, setConsultationId] = useState("demo-887scv");
  const [conversationKey, setConversationKey] = useState(null); // vet_chat:{id}
  const [messages, setMessages] = useState([]);
  const [connectionStatus, setConnectionStatus] = useState("idle"); // idle|connecting|connected|reconnecting
  const [turnPhase, setTurnPhase] = useState(null); // null|'sending'|'thinking'|'canceling'
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);

  const inputRef = useRef(null);
  const endRef = useRef(null);
  const esRef = useRef(null);
  const retryTimer = useRef(null);
  const firstConnect = useRef(false);      // true after first successful SSE connect
  const reconnectingRef = useRef(false);   // flip when we're reconnecting

  useEffect(() => {
    try {
      inputRef.current?.focus();
    } catch {}
  }, []);

  // Auto-scroll to last message
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // ───────────────────── History fetching helpers ─────────────────────
  const now = (d = new Date()) =>
    new Date(d).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  function toDisplayTs(tsLike) {
    try {
      return now(new Date(tsLike));
    } catch {
      return now();
    }
  }

  function mapHistoryMsgToUI(m) {
    const type = m.role === "user" ? "sent" : "received";
    const createdAt = m.created_at ? new Date(m.created_at) : new Date();
    return {
      type,
      text: m.content || "",
      isStreaming: false,
      lastChunk: "",
      timestamp: toDisplayTs(createdAt),
      createdAt, // keep original for resync cursors
    };
  }

  async function fetchFullHistory(id) {
    if (!id) return;
    setLoadingHistory(true);
    try {
      const url = `${API_BASE}/api/v1/vet_chat/${encodeURIComponent(id)}/history?limit=1000&order=asc`;
      const res = await fetch(url, { headers: { accept: "application/json" } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const mapped = (data?.messages || []).map(mapHistoryMsgToUI);
      setMessages(mapped);
    } catch (err) {
      addError(`Failed to load history: ${err.message}`);
      setMessages([]); // stay consistent
    } finally {
      setLoadingHistory(false);
    }
  }

  function getLastPersistedCreatedAt() {
    const persisted = messages.filter((m) => !!m.createdAt && m.isStreaming === false);
    if (persisted.length === 0) return null;
    return new Date(Math.max(...persisted.map((m) => m.createdAt.getTime())));
  }

  async function fetchHistoryAfter(id, afterDate) {
    if (!id || !afterDate) return;
    try {
      const q = new URLSearchParams({
        limit: String(500),
        order: "asc",
        after: afterDate.toISOString(),
      });
      const url = `${API_BASE}/api/v1/vet_chat/${encodeURIComponent(id)}/history?${q.toString()}`;
      const res = await fetch(url, { headers: { accept: "application/json" } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const incoming = (data?.messages || []).map(mapHistoryMsgToUI);
      if (incoming.length === 0) return;

      setMessages((prev) => {
        const key = (m) => `${m.type}|${m.createdAt?.toISOString?.() || ""}|${m.text}`;
        const existing = new Set(prev.map(key));
        const dedup = incoming.filter((m) => !existing.has(key(m)));
        return [...prev, ...dedup];
      });
    } catch (err) {
      addError(`Failed to resync history: ${err.message}`);
    }
  }

  // ───────────────────── Connect SSE for the current consultation ─────────────────────
  useEffect(() => {
    if (!consultationId) return;

    const key = `vet_chat:${consultationId}`;
    setConversationKey(key);
    setMessages([]);
    setTurnPhase(null);
    setIsCancelling(false);
    firstConnect.current = false;

    let stopped = false;
    let attempt = 0;

    // 1) Load historical messages right away
    fetchFullHistory(consultationId);

    const url = `${RELAY_BASE}/vet-chat-stream/${encodeURIComponent(
      consultationId
    )}?v=${Date.now()}`;

    const connect = () => {
      if (stopped) return;

      const reconnecting = attempt > 0;
      reconnectingRef.current = reconnecting;
      setConnectionStatus(attempt === 0 ? "connecting" : "reconnecting");

      try {
        esRef.current?.close();
      } catch {}

      const es = new EventSource(url);
      esRef.current = es;

      es.onopen = async () => {
        const wasReconnecting = attempt > 0;
        attempt = 0;
        setConnectionStatus("connected");

        if (!firstConnect.current) {
          addLog(`Connected to ${key}`);
          firstConnect.current = true;
        } else if (wasReconnecting) {
          const last = getLastPersistedCreatedAt();
          if (last) {
            await fetchHistoryAfter(consultationId, last);
          } else {
            await fetchFullHistory(consultationId);
          }
        }
      };

      // default message = plain text chunk
      es.onmessage = (e) => {
        handleIncomingChunk(e.data);
      };

      // status events (json)
      es.addEventListener("status", (e) => {
        try {
          const payload = JSON.parse(e.data || "{}");
          const phase = payload && payload.phase;

          if (phase === "started" || phase === "accepted" || phase === "thinking") {
            setTurnPhase("thinking");
          }

          if (phase === "cancel_requested") {
            setIsCancelling(true);
            setTurnPhase("canceling");
            addLog("Cancel requested…");
          }

          if (phase === "cancelled") {
            setIsCancelling(false);
            setTurnPhase(null);
            handleIncomingChunk("[END-OF-STREAM]"); // close any streaming bubble
            addLog("Turn cancelled.");
          }

          if (phase === "completed" || phase === "done" || phase === "error") {
            setTurnPhase(null);
            setIsCancelling(false);
            handleIncomingChunk("[END-OF-STREAM]");
          }
        } catch {}
      });

      // explicit done event from relay → finalize bubble
      es.addEventListener("done", () => {
        setTurnPhase(null);
        setIsCancelling(false);
        handleIncomingChunk("[END-OF-STREAM]");
      });

      // relay "error" (payload JSON)
      es.addEventListener("error", (e) => {
        setTurnPhase(null);
        setIsCancelling(false);
        try {
          const payload = JSON.parse(e.data || "{}");
          addError(payload?.message ? `Stream error: ${payload.message}` : "Stream error.");
        } catch {
          addError("Stream error.");
        }
        handleIncomingChunk("[END-OF-STREAM]");
      });

      // network / transport errors
      es.onerror = () => {
        setConnectionStatus("reconnecting");
        try {
          es.close();
        } catch {}
        attempt += 1;
        const delay = Math.min(1000 * Math.pow(2, attempt), 15000);
        clearTimeout(retryTimer.current);
        retryTimer.current = setTimeout(connect, delay);
      };
    };

    connect();

    return () => {
      stopped = true;
      try {
        esRef.current?.close();
      } catch {}
      clearTimeout(retryTimer.current);
      setConnectionStatus("idle");
    };
  }, [consultationId]);

  /* ───────────────────── Send message ───────────────────── */
  async function sendMessage() {
    const text = (inputRef.current?.value || "").trim();
    if (!text || !consultationId) return;

    try {
      setTurnPhase("sending");

      const res = await fetch(
        `${API_BASE}/api/v1/vet_chat/${encodeURIComponent(consultationId)}/message`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", accept: "application/json" },
          body: JSON.stringify({ message: text }),
        }
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const createdAt = new Date();
      setMessages((prev) => [
        ...prev,
        {
          type: "sent",
          text,
          isStreaming: false,
          timestamp: toDisplayTs(createdAt),
          createdAt,
        },
      ]);
      inputRef.current.value = "";
    } catch (err) {
      setTurnPhase(null);
      addError(`Failed to send: ${err.message}`);
    }
  }

  /* ───────────────────── Cancel current turn ───────────────────── */
  const canCancel =
    (messages.some((m) => m.type === "received" && m.isStreaming) ||
      turnPhase === "thinking" ||
      turnPhase === "sending") &&
    connectionStatus === "connected" &&
    !!consultationId;

  async function cancelTurn() {
    if (!canCancel || isCancelling) return;
    try {
      setIsCancelling(true);
      setTurnPhase("canceling");

      const res = await fetch(
        `${API_BASE}/api/v1/vet_chat/${encodeURIComponent(consultationId)}/cancel`,
        {
          method: "POST",
          headers: { accept: "application/json" },
        }
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      addLog("Cancel requested…");
      // The worker will emit status updates: cancel_requested → cancelled → done
      // We keep listening and closing the bubble on those events.
    } catch (err) {
      setIsCancelling(false);
      setTurnPhase(null);
      addError(`Failed to cancel: ${err.message}`);
    }
  }

  /* ───────────────────── Stream handling ───────────────────── */
  function handleIncomingChunk(raw) {
    const chunk = raw ?? "";
    const sentinel = "[END-OF-STREAM]";

    if (chunk.trim() === sentinel) {
      // Close whichever assistant bubble is currently streaming (even if not the last item)
      setMessages((prev) => {
        for (let j = prev.length - 1; j >= 0; j--) {
          const m = prev[j];
          if (m.type === "received" && m.isStreaming) {
            const copy = prev.slice();
            copy[j] = { ...m, isStreaming: false, lastChunk: "" };
            return copy;
          }
        }
        return prev; // nothing to close
      });
      return;
    }

    if (!chunk) return;

    // any data → we're streaming a reply
    setTurnPhase(null);

    setMessages((prev) => {
      // If last assistant message is streaming, append to it
      for (let j = prev.length - 1; j >= 0; j--) {
        const m = prev[j];
        if (m.type === "received" && m.isStreaming) {
          const copy = prev.slice();
          copy[j] = {
            ...m,
            text: (m.text || "") + chunk,
            lastChunk: chunk,
            animTick: Date.now(),
          };
          return copy;
        }
        if (m.type === "received") break;
      }

      // Otherwise, start a new assistant bubble
      const createdAt = new Date();
      return [
        ...prev,
        {
          type: "received",
          text: chunk,
          isStreaming: true,
          lastChunk: chunk,
          timestamp: toDisplayTs(createdAt),
          createdAt,
          animTick: Date.now(),
        },
      ];
    });
  }

  /* ───────────────────── Helpers ───────────────────── */
  const addLog = (text) =>
    setMessages((p) => [
      ...p,
      { type: "system", text, isStreaming: false, timestamp: now(), createdAt: new Date() },
    ]);
  const addError = (text) =>
    setMessages((p) => [
      ...p,
      { type: "error", text, isStreaming: false, timestamp: now(), createdAt: new Date() },
    ]);

  const isStreaming =
    messages.length > 0 && messages.some((m) => m.type === "received" && m.isStreaming);

  const connectionLabel = useMemo(() => {
    if (connectionStatus !== "connected") {
      return connectionStatus.charAt(0).toUpperCase() + connectionStatus.slice(1);
    }
    if (isCancelling || turnPhase === "canceling") return "Canceling…";
    if (isStreaming) return "Streaming…";
    if (turnPhase === "thinking") return "Thinking…";
    if (turnPhase === "sending") return "Sending…";
    if (loadingHistory) return "Loading history…";
    return "Connected";
  }, [connectionStatus, isStreaming, turnPhase, loadingHistory, isCancelling]);

  /* Render a single message bubble */
  function renderMessage(msg, i) {
    if (msg.type === "system" || msg.type === "error") {
      return (
        <div key={i} className="vc-system">
          <span className={`vc-system-pill ${msg.type}`}>{msg.text}</span>
        </div>
      );
    }

    const container = `vc-row ${msg.type}`;
    const bubble = `vc-bubble ${msg.type} ${msg.isStreaming ? "streaming" : ""}`;

    const full = msg.text || "";
    const tailCandidate = msg.isStreaming ? msg.lastChunk || "" : "";
    const shouldShowTail = !!tailCandidate && full.endsWith(tailCandidate);
    const stable = shouldShowTail ? full.slice(0, full.length - tailCandidate.length) : full;

    const html = mdToHtml(stable);

    return (
      <div key={i} className={container}>
        <div className={`vc-avatar ${msg.type}`} aria-hidden="true">
          {msg.type === "sent" ? "U" : "A"}
        </div>
        <div className={bubble}>
          <div className="vc-text">
            <div className="markdown" dangerouslySetInnerHTML={{ __html: html }} />
            {shouldShowTail && (
              <span key={msg.animTick} className="chunk-fade">
                {escapeHtml(tailCandidate)}
              </span>
            )}
          </div>
          <div className="vc-meta">
            <span className="vc-ts">{msg.timestamp}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="vc-root">
      {/* Header */}
      <header className="vc-header">
        <div className="vc-brand">
          <h1>Vet-Chat Tester</h1>
          <div className="vc-conn">
            <span className={`vc-dot ${connectionStatus}`} />
            <span className="vc-conn-label">{connectionLabel}</span>
          </div>
        </div>

        <div className="vc-controls">
          <div className="field">
            <label htmlFor="cid">Consultation ID</label>
            <input
              id="cid"
              value={consultationId}
              onChange={(e) => setConsultationId(e.target.value)}
              placeholder="demo-123"
            />
          </div>
          <button
            className="vc-reload"
            onClick={() => fetchFullHistory(consultationId)}
            title="Reload history"
            style={{ marginLeft: 8 }}
          >
            Reload
          </button>
          <button
            className={`vc-cancel ${canCancel ? "" : "disabled"}`}
            onClick={cancelTurn}
            disabled={!canCancel || isCancelling}
            title="Cancel current turn"
            style={{ marginLeft: 8 }}
          >
            {isCancelling ? "Canceling…" : "Cancel"}
          </button>
        </div>
      </header>

      {/* Small info line */}
      <div className="vc-sub">
        {conversationKey ? `Connected to ${conversationKey}` : "Not connected"}
      </div>

      {/* Messages */}
      <main className="vc-list" aria-live="polite">
        {messages.length === 0 ? (
          <div className="vc-empty">
            <div className="vc-empty-emoji" aria-hidden="true">
              💬
            </div>
            <h3>{loadingHistory ? "Loading history…" : "Start a conversation"}</h3>
            <p>{loadingHistory ? "Please wait." : "Type a message to begin."}</p>
          </div>
        ) : (
          messages.map((m, i) => renderMessage(m, i))
        )}
        <div ref={endRef} />
      </main>

      {/* Input */}
      <footer className="vc-input">
        <input
          ref={inputRef}
          type="text"
          placeholder="Type a message…"
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
        />
        <div className="vc-actions">
          <button
            className={`vc-cancel ${canCancel ? "" : "disabled"}`}
            onClick={cancelTurn}
            disabled={!canCancel || isCancelling}
            title="Cancel current turn"
            aria-label="Cancel streaming"
          >
            {isCancelling ? "Canceling…" : "Cancel"}
          </button>
          <button
            className="vc-send"
            onClick={sendMessage}
            title="Send"
            aria-label="Send message"
          >
            ➤
          </button>
        </div>
      </footer>
    </div>
  );
}
