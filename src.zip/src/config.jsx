// centralize so both testers share the same endpoints
export const API_BASE   = "https://chatbot-api-628790375254.us-east1.run.app";
// export const API_BASE = "http://localhost:8000";

export const RELAY_BASE = "https://chatbot-relay-628790375254.us-east1.run.app";
// export const RELAY_BASE = "http://localhost:8001";
